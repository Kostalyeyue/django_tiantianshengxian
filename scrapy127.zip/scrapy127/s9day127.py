s9day127 scrapy 

内容回顾：
	第一部分：爬虫
		1. scrapy依赖twisted
		
		2. twisted是什么以及和requests的区别？
			requests是一个Python实现的可以伪造浏览器发送Http请求的模块。
				- 封装socket发送请求
				
			twisted是基于事件循环的异步非阻塞网络框架。
				- 封装socket发送请求
				- 单线程完成并发请求
				PS: 三个相关词
					- 非阻塞：不等待
					- 异步：回调
					- 事件循环：一直循环去检查状态。
				
		3. Http请求本质
			
		4. scrapy 
			- response对象
				- text
				- body 
				- request 
			- xpath
				- //
				- /
				- .// 
				- //div[@x="xx"]
				- //div/text()
				- //div/@href
				-  .extract()
				-  .extract_first()
			- 持久化 
				- pipeline中5个方法
				- 爬虫中： yield Item对象
			
			- 再次发请求
				- yield Request对象
			
			- cookie

	第二部分：网络和并发
		1. OSI 7层模型
		
		2. 三次握手、四次挥手？
		
		3. TCP和UDP区别？
		
		4. 路由器和交换机的区别？
		
		5. ARP协议？
		
		6. DNS解析？
		
		7. Http和Https？
		
		8. 进程、线程、协程区别？
			greenlet是协程模块。
			gevent =》 greelet + IO切换
		
		9. GIL锁
		
		10. 进程如何进程共享？
		
今日内容：
	1. start_urls
	
	2. 下载中间件
		- 代理 
	
	3. 解析器
	
	4. 爬虫中间件
		- 深度
		- 优先级
		
内容详细：
	1. start_urls
		- 内部原理：
				"""
				scrapy引擎来爬虫中取起始URL：
					1. 调用start_requests并获取返回值
					2. v = iter(返回值)
					3. 
						req1 = 执行 v.__next__()
						req2 = 执行 v.__next__()
						req3 = 执行 v.__next__()
						...
					4. req全部放到调度器中
					
				"""
		- 编写
			class ChoutiSpider(scrapy.Spider):
				name = 'chouti'
				allowed_domains = ['chouti.com']
				start_urls = ['https://dig.chouti.com/']
				cookie_dict = {}
				
				def start_requests(self):
					# 方式一：
					for url in self.start_urls:
					    yield Request(url=url)
					# 方式二：
					# req_list = []
					# for url in self.start_urls:
					#     req_list.append(Request(url=url))
					# return req_list
					
					
		- 定制：可以去redis中获取
		
	2. 深度和优先级
		- 深度 
			- 最开始是0
			- 每次yield时，会根据原来请求中的depth + 1
			配置：DEPTH_LIMIT 深度控制
		- 优先级 
			- 请求被下载的优先级 -= 深度 * 配置 DEPTH_PRIORITY 
			配置：DEPTH_PRIORITY 
	
	3. 下载中间件
		- scrapy中设置代理 
			- 内置
				在爬虫启动时，提前在os.envrion中设置代理即可。
				    class ChoutiSpider(scrapy.Spider):
						name = 'chouti'
						allowed_domains = ['chouti.com']
						start_urls = ['https://dig.chouti.com/']
						cookie_dict = {}

						def start_requests(self):
							import os
							os.environ['HTTPS_PROXY'] = "http://root:woshiniba@192.168.11.11:9999/"
							os.environ['HTTP_PROXY'] = '19.11.2.32',
							for url in self.start_urls:
								yield Request(url=url,callback=self.parse)
				meta:
					class ChoutiSpider(scrapy.Spider):
						name = 'chouti'
						allowed_domains = ['chouti.com']
						start_urls = ['https://dig.chouti.com/']
						cookie_dict = {}

						def start_requests(self):
							for url in self.start_urls:
								yield Request(url=url,callback=self.parse,meta={'proxy':'"http://root:woshiniba@192.168.11.11:9999/"'})

			- 自定义
				# by luffycity.com
				import base64
				import random
				from six.moves.urllib.parse import unquote
				try:
					from urllib2 import _parse_proxy
				except ImportError:
					from urllib.request import _parse_proxy
				from six.moves.urllib.parse import urlunparse
				from scrapy.utils.python import to_bytes

				class XdbProxyMiddleware(object):

					def _basic_auth_header(self, username, password):
						user_pass = to_bytes(
							'%s:%s' % (unquote(username), unquote(password)),
							encoding='latin-1')
						return base64.b64encode(user_pass).strip()

					def process_request(self, request, spider):
						PROXIES = [
							"http://root:woshiniba@192.168.11.11:9999/",
							"http://root:woshiniba@192.168.11.12:9999/",
							"http://root:woshiniba@192.168.11.13:9999/",
							"http://root:woshiniba@192.168.11.14:9999/",
							"http://root:woshiniba@192.168.11.15:9999/",
							"http://root:woshiniba@192.168.11.16:9999/",
						]
						url = random.choice(PROXIES)

						orig_type = ""
						proxy_type, user, password, hostport = _parse_proxy(url)
						proxy_url = urlunparse((proxy_type or orig_type, hostport, '', '', '', ''))

						if user:
							creds = self._basic_auth_header(user, password)
						else:
							creds = None
						request.meta['proxy'] = proxy_url
						if creds:
							request.headers['Proxy-Authorization'] = b'Basic ' + creds
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		https://www.cnblogs.com/wupeiqi/articles/6229292.html
		
		- 选择器
		
		问题：scrapy如何加代理？
	
	
	4. 解析器：xpath
		
	5. 使用cookie
		 - 手动
		 - 自动 
			meta={'cookiejar': True}
	
	
	
	
	
	
	
	
	