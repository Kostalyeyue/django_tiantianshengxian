# -*- coding: utf-8 -*-
import scrapy
from scrapy.http.response.html import HtmlResponse
# import sys,os,io
# sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='gb18030')
from xdb.items import XdbItem
import scrapy
from scrapy.http.cookies import CookieJar
from scrapy.http import Request
from urllib.parse import urlencode


"""
scrapy引擎来爬虫中取起始URL：
    1. 调用start_requests并获取返回值
    2. v = iter(返回值)
    3. 
        req1 = 执行 v.__next__()
        req2 = 执行 v.__next__()
        req3 = 执行 v.__next__()
        ...
    4. req全部放到调度器中
    
"""
class ChoutiSpider(scrapy.Spider):
    name = 'chouti'
    allowed_domains = ['chouti.com']
    start_urls = ['https://dig.chouti.com/']
    cookie_dict = {}

    def start_requests(self):
        for url in self.start_urls:
            yield Request(url=url,callback=self.parse)

    def parse(self, response):
        """
        第一次访问抽屉返回的内容：response
        :param response:
        :return:
        """
        from scrapy.spidermiddlewares.depth import DepthMiddleware
        from scrapy.http import Response
        # response.request
        # response.request.meta
        print(response.meta.get('depth',0)) # 0
        # response.request.meta['depth'] = 0

        page_list = response.xpath('//div[@id="dig_lcpage"]//a/@href').extract()
        for page in page_list:
            page = "https://dig.chouti.com" + page
            yield Request(url=page, callback=self.parse)











