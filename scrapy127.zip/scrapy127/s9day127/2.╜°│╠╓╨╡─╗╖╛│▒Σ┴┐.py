# by luffycity.com


import os

print(os.environ)

os.environ['XXX'] = "123"

input("?>>>")
print(os.environ['XXX'])


