# by luffycity.com
"""

"""

"""
# 可迭代对象
# li = [11,22,33]

# 可迭代对象转换为迭代器
# iter(li)



def func():
    yield 11
    yield 22
    yield 33

# 生成器
li = func()

# 生成器 转换为迭代器
iter(li)


v = li.__next__()
print(v)
"""


def get_all(arg):

    data = iter(arg)
    print(data.__next__())













