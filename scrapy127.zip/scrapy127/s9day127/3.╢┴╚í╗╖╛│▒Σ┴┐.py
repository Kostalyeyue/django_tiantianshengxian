# by luffycity.com
import os

v = os.environ.get('XXX')
print(v)