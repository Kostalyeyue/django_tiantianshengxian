# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import HtmlResponse

class CnblogsSpider(scrapy.Spider):
    name = 'cnblogs'
    allowed_domains = ['cnblogs.com']
    start_urls = ['http://cnblogs.com/']

    def parse(self, response):
        pass
