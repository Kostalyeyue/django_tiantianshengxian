# by luffycity.com


class Request(object):

    def __init__(self,url,callback):
        self.url = url
        self.callback = callback


Request(url='hxfasdfasdfasdf',callback=lambda x:x )