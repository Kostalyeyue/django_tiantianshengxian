# by luffycity.com
from scrapy.utils.request import request_fingerprint
from scrapy.http import Request


url1 = "http://www.luffycity.com?k1=123&k2=456"
req1 = Request(url=url1)
url2 = "http://www.luffycity.com?k2=456&k1=123"
req2 = Request(url=url2)

fd1 = request_fingerprint(request=req1)
fd2 = request_fingerprint(request=req2)
print(fd1)
print(fd2)