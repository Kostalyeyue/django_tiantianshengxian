"""

"""


# 原来
"""
import requests

url_list = ['http://www.baidu.com', 'http://www.baidu.com', 'http://www.baidu.com', ]

for item in url_list:
    response = requests.get(item)
    print(response.text)

"""

# 现在
"""
非阻塞，不等待； 我向贝贝、高件套、小东北发起连接请求时候，不等连接再去连下一个，而是发送一个只会，马上发送下一个。

    import socket 
    sk = socket.socket()
    sk.setblocking(False)
    sk.connect((1.1.1.1,80))
    
    import socket 
    sk = socket.socket()
    sk.setblocking(False)
    sk.connect((1.1.1.2,80))
    
    import socket 
    sk = socket.socket()
    sk.setblocking(False)
    sk.connect((1.1.1.3,80))

异步，回调; 我帮助龙泰、呼呼、刘淞找到想要的人只会，我会主动通知他们。
    def callback(contents):
    print(contents)
事件循环; 我，我一直在循环三个socket任务（即：贝贝、高件套、小东北），检查他三个状态：是否连接成功；是否返回结果。


总结：
    官方：基于事件循环的异步非阻塞模块。
    白话：一个线程同时可以向多个目标发起Http请求。
    
"""

from twisted.web.client import getPage, defer
from twisted.internet import reactor

# 第一部分：代理开始接收任务
def callback(contents):
    print(contents)

deferred_list = [] # [(龙泰,贝贝),(刘淞，宝件套),(呼呼,东北)]
url_list = ['http://www.bing.com', 'https://segmentfault.com/','https://stackoverflow.com/' ]
for url in url_list:
    deferred = getPage(bytes(url, encoding='utf8')) # (我,要谁)
    deferred.addCallback(callback)
    deferred_list.append(deferred)


# # 第二部分：代理执行完任务后，停止
dlist = defer.DeferredList(deferred_list)

def all_done(arg):
    reactor.stop()

dlist.addBoth(all_done)

# 第三部分：代理开始去处理吧
reactor.run()

