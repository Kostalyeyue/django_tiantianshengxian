# by luffycity.com


class Foo(object):

    def __init__(self):
        self.f = None

    def open(self):
        self.f = 123

    def close(self):
        print(self.f)

obj = Foo()
obj.open()
print(obj.f)