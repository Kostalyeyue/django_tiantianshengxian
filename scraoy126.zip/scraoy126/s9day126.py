s9day126 

内容回顾：
	第一部分：scrapy框架
		1. scrapy依赖twisted
			内部基于事件循环的机制实现爬虫的并发。
			原来的你：
				url_list = ['http://www.baidu.com','http://www.baidu.com','http://www.baidu.com',]
				
				for item in url_list:
					response = requests.get(item)
					print(response.text)
			
			现在：				
				from twisted.web.client import getPage, defer
				from twisted.internet import reactor

				# 第一部分：代理开始接收任务
				def callback(contents):
					print(contents)

				deferred_list = [] # [(龙泰,贝贝),(刘淞，宝件套),(呼呼,东北)]
				url_list = ['http://www.bing.com', 'https://segmentfault.com/','https://stackoverflow.com/' ]
				for url in url_list:
					deferred = getPage(bytes(url, encoding='utf8')) # (我,要谁)
					deferred.addCallback(callback)
					deferred_list.append(deferred)


				# # 第二部分：代理执行完任务后，停止
				dlist = defer.DeferredList(deferred_list)

				def all_done(arg):
					reactor.stop()

				dlist.addBoth(all_done)

				# 第三部分：代理开始去处理吧
				reactor.run()
		
		2. scrapy 
			命令：
				scrapy startproject xx 
				cd xx 
				scrapy genspider chouti chouti.com 
				
				scrapy crawl chouti --nolog 
			
			编写：
				def parse(self,response):
					# 1.响应
					# response封装了响应相关的所有数据：
						- response.text 
						- response.encoding
						- response.body 
						- response.request # 当前响应是由那个请求发起；请求中 封装（要访问的url，下载完成之后执行那个函数）
					# 2. 解析
					# response.xpath('//div[@href="x1"]/a').extract_first()
					# response.xpath('//div[@href="x1"]/a').extract()
					# response.xpath('//div[@href="x1"]/a/text()').extract()
					# response.xpath('//div[@href="x1"]/a/@href').extract()
					# tag_list = response.xpath('//div[@href="x1"]/a')
					for tag in tag_list:
						tag.xpath('.//p/text()').extract_first()
						
					# 3. 再次发起请求
					# yield Request(url='xxxx',callback=self.parse)
	
	第二部分： 
		1. OSI 7/5 层模型
		
		2. 三次握手、四次挥手？
		
		3. TCP和UDP区别？
		
		4. 路由器和交换机的区别？
		
		5. ARP协议？
			
		6. DNS解析？
		
		7. Http和Https？
		
		8. 进程、线程、协程区别？
		
		9. GIL锁
			全局解释器锁，保证同一时刻一个进程只有一个线程被CPU调度。
			数据安全：自己加锁。
		10. 进程如何进程共享？
			- queque
			- pipe 
			- manager
					
今日内容：scrapy
	- 持久化 pipeline/items
	
	- 去重 
	
	- cookie 
	
	- 组件流程： 
		- 下载中间件
		
	- 深度
	
内容详细：

	1. 持久化 
		目前缺点：
			- 无法完成爬虫刚开始：打开连接； 爬虫关闭时：关闭连接；
			- 分工明确
		pipeline/items
			a. 先写pipeline类
				class XXXPipeline(object):
					def process_item(self, item, spider):
						return item
						
			b. 写Item类
				class XdbItem(scrapy.Item):
					href = scrapy.Field()
					title = scrapy.Field()
							
			c. 配置
				ITEM_PIPELINES = {
				   'xdb.pipelines.XdbPipeline': 300,
				}
			
			d. 爬虫，yield每执行一次，process_item就调用一次。
				
				yield Item对象
		
		编写pipeline：
			from scrapy.exceptions import DropItem

			class FilePipeline(object):

				def __init__(self,path):
					self.f = None
					self.path = path

				@classmethod
				def from_crawler(cls, crawler):
					"""
					初始化时候，用于创建pipeline对象
					:param crawler:
					:return:
					"""
					print('File.from_crawler')
					path = crawler.settings.get('HREF_FILE_PATH')
					return cls(path)

				def open_spider(self,spider):
					"""
					爬虫开始执行时，调用
					:param spider:
					:return:
					"""
					print('File.open_spider')
					self.f = open(self.path,'a+')

				def process_item(self, item, spider):
					# f = open('xx.log','a+')
					# f.write(item['href']+'\n')
					# f.close()
					print('File',item['href'])
					self.f.write(item['href']+'\n')
					
					# return item  	# 交给下一个pipeline的process_item方法
					raise DropItem()# 后续的 pipeline的process_item方法不再执行

				def close_spider(self,spider):
					"""
					爬虫关闭时，被调用
					:param spider:
					:return:
					"""
					print('File.close_spider')
					self.f.close()


		注意：pipeline是所有爬虫公用，如果想要给某个爬虫定制需要使用spider参数自己进行处理。
		
	
	2. 去重规则
		
		
		a. 编写类 
			from scrapy.dupefilter import BaseDupeFilter
			from scrapy.utils.request import request_fingerprint

			class XdbDupeFilter(BaseDupeFilter):

				def __init__(self):
					self.visited_fd = set()

				@classmethod
				def from_settings(cls, settings):
					return cls()

				def request_seen(self, request):
					fd = request_fingerprint(request=request)
					if fd in self.visited_fd:
						return True
					self.visited_fd.add(fd)

				def open(self):  # can return deferred
					print('开始')

				def close(self, reason):  # can return a deferred
					print('结束')

				# def log(self, request, spider):  # log that a request has been filtered
				#     print('日志')

		b. 配置 
			# 修改默认的去重规则
			# DUPEFILTER_CLASS = 'scrapy.dupefilter.RFPDupeFilter'
			DUPEFILTER_CLASS = 'xdb.dupefilters.XdbDupeFilter'


		c. 爬虫使用：
			class ChoutiSpider(scrapy.Spider):
				name = 'chouti'
				allowed_domains = ['chouti.com']
				start_urls = ['https://dig.chouti.com/']

				def parse(self, response):
					print(response.request.url)
					# item_list = response.xpath('//div[@id="content-list"]/div[@class="item"]')
					# for item in item_list:
					#     text = item.xpath('.//a/text()').extract_first()
					#     href = item.xpath('.//a/@href').extract_first()

					page_list = response.xpath('//div[@id="dig_lcpage"]//a/@href').extract()
					for page in page_list:
						from scrapy.http import Request
						page = "https://dig.chouti.com" + page
						# yield Request(url=page,callback=self.parse,dont_filter=False) # https://dig.chouti.com/all/hot/recent/2
						yield Request(url=page,callback=self.parse,dont_filter=True) # https://dig.chouti.com/all/hot/recent/2
		
		注意： 
			- request_seen中编写正确逻辑
			- dont_filter=False


	
	3. 深度 
		配置文件：
			# 限制深度
			DEPTH_LIMIT = 3


	4. cookie 
		方式一：
			- 携带 
				Request(
					url='https://dig.chouti.com/login',
					method='POST',
					body="phone=8613121758648&password=woshiniba&oneMonth=1",# # body=urlencode({})"phone=8615131255555&password=12sdf32sdf&oneMonth=1"
					cookies=self.cookie_dict,
					headers={
						'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
					},
					callback=self.check_login
				)
			
			- 解析：
					cookie_dict
					cookie_jar = CookieJar()
					cookie_jar.extract_cookies(response, response.request)

					# 去对象中将cookie解析到字典
					for k, v in cookie_jar._cookies.items():
						for i, j in v.items():
							for m, n in j.items():
								cookie_dict[m] = n.value
		方式二：meta
		
			










